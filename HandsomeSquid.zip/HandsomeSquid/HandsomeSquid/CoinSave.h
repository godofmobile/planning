//
//  CoinSave.h
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoinSave : NSObject

@property int coin;

@end
