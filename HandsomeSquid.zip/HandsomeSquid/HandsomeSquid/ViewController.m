//
//  ViewController.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "ViewController.h"
#import "GameViewController.h"
#import "LevelViewController.h"
#import "AvataViewController.h"
#import "HandSomeDB_ios.h"
#import "CoinSave.h"

@interface ViewController ()

@end

@implementation ViewController

UIButton *btnOption[5];

UIView *boxView;

UILabel *countCoin;

int check = 0;


- (void)viewDidLoad {
    
    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    [hsDB createTable];
    CoinSave *cs = [hsDB loadCoin];
    int totalCoin = cs.coin;
    [hsDB databaseClose];
    
    
    //배경화면
    UIImage *backgroundImage = [UIImage imageNamed:@"background_main.png"];
    UIImageView *backgroundImageView = [[UIImageView alloc]initWithImage:backgroundImage];
    [backgroundImageView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:backgroundImageView];
    
    UIImage *image_start = [UIImage imageNamed:@"game_start_before_click.png"];
    UIButton *button_start = [UIButton buttonWithType:UIButtonTypeCustom];
    [button_start setImage:image_start forState:UIControlStateNormal];
    [button_start setFrame:CGRectMake(self.view.frame.size.width/2-image_start.size.width/2, self.view.frame.size.height/7*4.5, image_start.size.width, image_start.size.height)];
    [button_start addTarget:self action:@selector(buttonclicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button_start];
    
    

    UIImage *barImage = [UIImage imageNamed:@"button_shadow_bar.png"];
    UIImageView *barmageView = [[UIImageView alloc]initWithImage:barImage];
    [barmageView setFrame:CGRectMake(0, self.view.frame.size.height-barImage.size.height, self.view.frame.size.width, barImage.size.height)];
    [self.view addSubview:barmageView];
    
    UIImage *btnImage[5];
    for (int a = 0; a <5; a++) {
        btnImage[a] = [UIImage imageNamed:[NSString stringWithFormat:@"button_bar_%i.png",a+1]];
        btnOption[a] = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnOption[a] setImage:btnImage[a] forState:UIControlStateNormal];
        [btnOption[a] setFrame:CGRectMake(self.view.frame.size.width/5*a, barmageView.frame.origin.y+15, btnImage[a].size.width, btnImage[a].size.height)];
        btnOption[a].tag = a+1;
        [btnOption[a] addTarget:self action:@selector(buttinSelected:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btnOption[a]];
    }

    boxView = [[UIView alloc]initWithFrame:CGRectMake(btnOption[3].frame.origin.x-20, btnOption[3].frame.origin.y-50, 99, 39)];
    [self.view addSubview:boxView];
    UIImage *image_box = [UIImage imageNamed:@"blackbox_level_time.png"];
    UIImageView *imageView_box = [[UIImageView alloc]initWithImage:image_box];
    [imageView_box setFrame:CGRectMake(0, 0, boxView.frame.size.width, boxView.frame.size.height)];
    [boxView addSubview:imageView_box];
    [imageView_box setContentMode:UIViewContentModeScaleToFill];
    
    countCoin = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, boxView.frame.size.width-10, boxView.frame.size.height)];
    [countCoin setText:[NSString stringWithFormat:@"%i o",totalCoin]];
    [countCoin setTextAlignment:NSTextAlignmentRight];
    [countCoin setTextColor:[UIColor whiteColor]];
    [countCoin setFont:[UIFont fontWithName:@"Arial-BoldMT" size:16]];
    [boxView addSubview:countCoin];

    boxView.alpha = 0.0f;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated{
    /*
    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    
    CoinSave *cs = [hsDB loadCoin];
    int totalCoin = cs.coin;
    [hsDB databaseClose];
     */
}

-(void)buttonclicked{
    NSLog(@"메뉴View로 이동");
    GameViewController *menuviewController = [[GameViewController alloc] init];
    [self presentViewController:menuviewController animated:NO completion:nil];
}

-(void)buttinSelected:(UIButton*)sender{
    
    NSLog(@"test : tage  - %i",(int)sender.tag);
    
    if (sender.tag == 1) {
        
        NSLog(@"게임셋팅");
        
    }else if (sender.tag == 2){
        
        NSLog(@"난이도 설정");
        check = 0;
        LevelViewController *levevlviewController = [[LevelViewController alloc] init];
        [self presentViewController:levevlviewController animated:NO completion:nil];
        
    }else if (sender.tag == 3){
        
        NSLog(@"아바타 설정");
        check = 0;
        AvataViewController *avaViewController = [[AvataViewController alloc] init];
        [self presentViewController:avaViewController animated:NO completion:nil];
        
    }else if (sender.tag == 4){
        
        HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
        [hsDB openDB];
        [hsDB createTable];
        CoinSave *cs = [hsDB loadCoin];
        int totalCoin = cs.coin;
        [hsDB databaseClose];
        [countCoin setText:[NSString stringWithFormat:@"%i o",totalCoin]];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.70];
        [UIView setAnimationDelay:0.0];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        if (check == 0) {
            check = 1;
            [boxView setAlpha:1.0f];
        }else{
            [boxView setAlpha:0.0f];
            check = 0;
        }
        
        [UIView commitAnimations];
    }else if (sender.tag == 5){
        check = 0;
        NSLog(@"쿠폰함");
        
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
