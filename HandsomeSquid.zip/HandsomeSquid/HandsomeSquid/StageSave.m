//
//  StageSave.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "StageSave.h"

@implementation StageSave

@synthesize stage;

@end
