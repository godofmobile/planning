//
//  GameViewController.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "GameViewController.h"
#import "ViewController.h"
#import "HandSomeDB_ios.h"
#import "StageSave.h"
#import "CoinSave.h"

@interface GameViewController ()

@end

@implementation GameViewController

@synthesize levelSet;

int timer_count = 0;
int timer_count_1 = 0;
int timer_count_2 = 0;
int x_loop_count = 0;
int ly_loop = 0;
int ry_loop = 0;

int life_count = 5;

int View_count = 0;

int time_countDown;
int time_counter = 0;

int score_total;

int continueTimer = 0;
int introViewCount = 0;

int result_num = 0;
int chracter_move = 0;
int levelOneSet = 0;
int bonusView = 0;
int callBonusView = 1;

int lifeCount_set = 5;

UILabel *score_label;
UILabel *time_label;

UIButton *enermyX[20];
UIButton *enermyLY[10];
UIButton *enermyRY[10];
UIButton *button_ch[6][10];

UIImage *moster_befroe;
UIImage *lifeImage;
UIImage *lostImage;
UIImage *introStartImage;
UIImage *monster_image_after;

UIImageView *center_imageView;
UIImageView *lifeCount[5];
UIImageView *introText;
UIImageView *introView;
//UIImageView *avataView;

UIView *chansView = NULL;

NSTimer *timer;




- (void)viewDidLoad {
    
    [self levelCheck];
   
    UIImage *imageback = [UIImage imageNamed:@"background_cafe.png"];
    UIImageView *imageViewback = [[UIImageView alloc]initWithImage:imageback];
    [imageViewback setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:imageViewback];
    
    UIImage *image_bar = [UIImage imageNamed:@"playing_page_bar.png"];
    UIImageView *imageView_bar = [[UIImageView alloc]initWithImage:image_bar];
    [imageView_bar setFrame:CGRectMake(0, self.view.frame.size.height-image_bar.size.height, self.view.frame.size.width, image_bar.size.height)];
    [self.view addSubview:imageView_bar];
    
    lostImage = [UIImage imageNamed:@"playing_life_lost_new.png"];
    lifeImage = [UIImage imageNamed:@"playing_life_new.png"];
    for (int count = 0; count < 5; count++) {
        lifeCount[count] = [[UIImageView alloc]initWithImage:lifeImage];
        [lifeCount[count] setFrame:CGRectMake(25+ (lifeImage.size.width+2)*count, 20, lifeImage.size.width, lifeImage.size.height)];
        [imageView_bar addSubview:lifeCount[count]];
    }
    
    
    time_label = [[UILabel alloc]initWithFrame:CGRectMake(imageView_bar.frame.size.width-70, -13, 85, 70)];
    [time_label setFont:[UIFont fontWithName:@"Arial-BoldMT" size:20]];
    [time_label setText:[NSString stringWithFormat:@"%i",time_countDown]];
    [time_label setTextColor:[UIColor whiteColor]];
    [imageView_bar addSubview:time_label];
    
    
    score_total = 0;
    
    score_label = [[UILabel alloc]initWithFrame:CGRectMake(imageView_bar.frame.size.width-150, 18, 85, 70)];
    [score_label setTextColor:[UIColor whiteColor]];
    [score_label setFont:[UIFont fontWithName:@"Arial-BoldMT" size:20]];
    [score_label setText:[NSString stringWithFormat:@"%i",score_total]];
    [score_label setTextAlignment:NSTextAlignmentRight];
    [imageView_bar addSubview:score_label];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(time:) userInfo:nil repeats:YES];
    
    moster_befroe = [UIImage imageNamed:@"playing_monster_before.png"];
    monster_image_after =[UIImage imageNamed:@"playing_monster_after.png"];
    UIImage *centerImage = [UIImage imageNamed:[NSString stringWithFormat:@"playing_girl_type_%i.png",levelSet]];
    center_imageView = [[UIImageView alloc]initWithImage:centerImage];
    [center_imageView setFrame:CGRectMake(self.view.frame.size.width/2-50, 300, 100, 180)];
    [self.view addSubview:center_imageView];
    
    for (int a = 0; a< 20; a++) {
        enermyX[a] = [UIButton buttonWithType:UIButtonTypeCustom];
        [enermyX[a] setImage:moster_befroe forState:UIControlStateNormal];
        [enermyX[a] addTarget:self action:@selector(EnermyClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        enermyX[a].frame = CGRectMake(0, -100, 60, 60);
        enermyX[a].tag = 1000;
        [self.view addSubview:enermyX[a]];
    }
    for (int a = 0; a< 10; a++) {
        
        enermyRY[a] = [UIButton buttonWithType:UIButtonTypeCustom];
        [enermyRY[a] setImage:moster_befroe forState:UIControlStateNormal];
        [enermyRY[a] addTarget:self action:@selector(EnermyClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        enermyLY[a] = [UIButton buttonWithType:UIButtonTypeCustom];
        [enermyLY[a] setImage:moster_befroe forState:UIControlStateNormal];
        [enermyLY[a] addTarget:self action:@selector(EnermyClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        enermyRY[a].frame = CGRectMake(0, -100, 60, 60);
        enermyLY[a].frame = CGRectMake(0, -100, 60, 60);
        
        enermyRY[a].tag = 1000;
        enermyLY[a].tag = 1000;
        
        [self.view addSubview:enermyLY[a]];
        [self.view addSubview:enermyRY[a]];
    }
    
    UIImage *introimage = [UIImage imageNamed:@"background_shadow.png"];
    introView = [[UIImageView alloc]initWithImage:introimage];
    [introView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:introView];
    
    UIImage *introReadyImage = [UIImage imageNamed:@"playing_before_tiping_ready.png"];
    introStartImage = [UIImage imageNamed:@"playing_before_tiping_start.png"];
    introText = [[UIImageView alloc]initWithImage:introReadyImage];
    [introText setFrame:CGRectMake(self.view.frame.size.width/2 - introReadyImage.size.width/2, self.view.frame.size.height/2-introReadyImage.size.height/2, introReadyImage.size.width, introReadyImage.size.height)];
    [self.view addSubview:introText];

    
    /*
     UIImage *character = [UIImage imageNamed:@"avata_ver2.png"];
     avataView = [[UIImageView alloc]initWithImage:character];
     [avataView setFrame:CGRectMake(self.view.frame.size.width/2-25, 0, 50, 80)];
     avataView.alpha = 0.0f;
     [self.view addSubview:avataView];
     */
    NSURL *musicFile = [[NSBundle mainBundle] URLForResource:@"backgroundSound"
                                               withExtension:@"mp3"];
    self.backgroundMusic = [[AVAudioPlayer alloc] initWithContentsOfURL:musicFile
                                                                  error:nil];
    self.backgroundMusic.numberOfLoops = -1;
    [self.backgroundMusic play];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)time:(id)ss{
    continueTimer++;
    if (continueTimer >150  && introViewCount == 0) {
        introViewCount = 1;
        [introText setImage:introStartImage];
        [introText setFrame:CGRectMake(self.view.frame.size.width/2 - introStartImage.size.width/2, self.view.frame.size.height/2-introStartImage.size.height/2, introStartImage.size.width, introStartImage.size.height)];
    }
    if (continueTimer >280 && introViewCount == 1) {
        introViewCount = 2;
        [introText setFrame:CGRectMake(1000, 0, introStartImage.size.width, introStartImage.size.height)];
        [introView setFrame:CGRectMake(1000, 0, self.view.frame.size.width, self.view.frame.size.height)];
        [introText removeFromSuperview];
        [introView removeFromSuperview];
        //        avataView.alpha = 1.0f;
    }
    if (continueTimer < 300) return;
    timer_count++;
    timer_count_1++;
    timer_count_2++;
    
    time_counter++;
    
    if (lifeCount_set != life_count) {
        NSLog(@"lifeCount_set = %i / life_count = %i",lifeCount_set, life_count);
        lifeCount_set = life_count;
        if (lifeCount_set > -1) {
            [lifeCount[lifeCount_set] setImage:lostImage];
        }
    }

    
    if (time_counter >=98) {
        time_counter = 0;
        time_countDown--;
        bonusView++;// 보너스시간
        //chracter_move++;
    
        [time_label setText:[NSString stringWithFormat:@"%i",time_countDown]];
        //[avataView setFrame:CGRectMake(self.view.frame.size.width/2-25, 300/120*chracter_move, 50, 80)];
        if (time_countDown <= 0) { //미션성공
            [timer invalidate];
            result_num = 2;
            [self CheckView];
            [self.backgroundMusic stop];
            return;
        }
    }
    
    if (x_loop_count >= 20 )
        x_loop_count = 0;
    if (ly_loop >= 10)
        ly_loop = 0;
    if (ry_loop >= 10)
        ry_loop = 0;
    
    if(life_count <= 0){ // 미션실패
        
        [timer invalidate];
        [self.backgroundMusic stop];
        
        if (View_count == 0) {
            result_num = 1;
            [self CheckView];
            
        }
        return;
        
    }
    
    if(levelSet == 3 && bonusView >60 && bonusView <= 72){
        
        if (callBonusView == 1 && bonusView >60 && bonusView < 62) {
            callBonusView = 2;
        }
        if (callBonusView == 2 && bonusView >=62 && bonusView < 72) {
            [self chanceView];
            callBonusView = 3;
        }
        if (callBonusView == 3 && bonusView == 72) {
            callBonusView = 4;
            [chansView removeFromSuperview];
        }
        
        return;
    }
    /***************  X축 기준  *****************/
    
    if(timer_count > levelOneSet ){
        
        int randomPositonX = -100 + ((rand()%((int)self.view.frame.size.width+150))/10*10);
        [enermyX[x_loop_count] setFrame:CGRectMake(randomPositonX, 0, 60, 60)];
        enermyX[x_loop_count].tag = x_loop_count;
        
        timer_count = 0;
        x_loop_count++;
    }
    //NSLog(@"timer_count = %i // x_loop_count = %i",timer_count, x_loop_count);
    
    for (int count = 0; count<20; count++) {
        if(enermyX[count] != nil){
            float xChege = enermyX[count].frame.origin.x;
            float yChege = enermyX[count].frame.origin.y;
            if(enermyX[count].tag < 900){
                if(enermyX[count].frame.origin.x <= self.view.frame.size.width/2-25 && enermyX[count].frame.origin.y < self.view.frame.size.height/2){
                    enermyX[count].frame = CGRectMake(xChege+0.5, yChege+1, enermyX[count].frame.size.width, enermyX[count].frame.size.height);
                    
                    
                }
                if(enermyX[count].frame.origin.x > self.view.frame.size.width/2-25 && enermyX[count].frame.origin.y < self.view.frame.size.height/2){
                    enermyX[count].frame = CGRectMake(xChege-0.5, yChege+1, enermyX[count].frame.size.width, enermyX[count].frame.size.height);
                    
                }
                if(enermyX[count].frame.origin.x + enermyX[count].frame.size.width >= self.view.frame.size.width/2-center_imageView.frame.size.width/2 && enermyX[count].frame.origin.x <= self.view.frame.size.width/2 + center_imageView.frame.size.width/2 && enermyX[count].frame.origin.y +enermyX[count].frame.size.height >= center_imageView.frame.origin.y){
                    
                    enermyX[count].tag = 1000;
                    enermyX[count].frame = CGRectMake(-100, 0, 60, 60);
                    //[lifeCount[life_count-1] setImage:lostImage];
                    
                    life_count--;
                    NSLog(@"life_count1111 = %i enermyX[%i] ",life_count, count);
                    
                }
            }
            
        }
    }
    
    if(levelSet <2)return; //level 2이상일 경우
    
    if (lifeCount_set != life_count) {
        NSLog(@"lifeCount_set = %i / life_count = %i",lifeCount_set, life_count);
        lifeCount_set = life_count;
        if (lifeCount_set > -1) {
            [lifeCount[lifeCount_set] setImage:lostImage];
        }
    }
    /***************  Left Y축 기준  *****************/
    
    if(timer_count_1 > 140 ){
    
        int randomPositonX = (rand()%(((int)self.view.frame.size.height-200)/10))*10;
        [enermyLY[ly_loop] setFrame:CGRectMake(0, randomPositonX, 60, 60)];
        enermyLY[ly_loop].tag = ly_loop;
        
        timer_count_1 = 0;
        ly_loop++;
    }
    
    for (int count = 0; count<10; count++) {
        if(enermyLY[count] != nil){
            if(enermyLY[count].tag < 900){
                float xChege = enermyLY[count].frame.origin.x;
                float yChege = enermyLY[count].frame.origin.y;
                
                if(enermyLY[count].frame.origin.x <= self.view.frame.size.width/2-25 && enermyLY[count].frame.origin.y < self.view.frame.size.height/2){
                    enermyLY[count].frame = CGRectMake(xChege+0.5, yChege+1, enermyLY[count].frame.size.width, enermyLY[count].frame.size.height);
                    
                }
                if(enermyLY[count].frame.origin.x <= self.view.frame.size.width/2-25 && enermyLY[count].frame.origin.y >= self.view.frame.size.height/2){
                    enermyLY[count].frame = CGRectMake(xChege+0.5, yChege-1, enermyLY[count].frame.size.width, enermyX[count].frame.size.height);
                }
                if(enermyLY[count].frame.origin.x + enermyLY[count].frame.size.width >= self.view.frame.size.width/2-center_imageView.frame.size.width/2 && enermyLY[count].frame.origin.x <= self.view.frame.size.width/2 + center_imageView.frame.size.width/2 && enermyLY[count].frame.origin.y +enermyLY[count].frame.size.height >= center_imageView.frame.origin.y){
                    
                    enermyLY[count].tag = 1000;
                    enermyLY[count].frame = CGRectMake(-100, 0, 60, 60);
                    //[lifeCount[life_count-1] setImage:lostImage];
                    life_count--;
                    NSLog(@"life_count22 = %i enermyLY[%i] ",life_count, count);
                    
                }
            }
        }
    }
    
    if (lifeCount_set != life_count) {
        NSLog(@"lifeCount_set = %i / life_count = %i",lifeCount_set, life_count);
        lifeCount_set = life_count;
        if (lifeCount_set > -1) {
            [lifeCount[lifeCount_set] setImage:lostImage];
        }
    }
    /***************  Right Y축 기준  *****************/
    
    if(timer_count_2 > 120 ){
        
        int randomPositonX = (rand()%(((int)self.view.frame.size.height-200)/10))*10;
        [enermyRY[ry_loop] setFrame:CGRectMake(self.view.frame.size.width-60, randomPositonX, 60, 60)];
        enermyRY[ry_loop].tag = ry_loop;
        
        timer_count_2 = 0;
    }
    for (int count = 0; count<10; count++) {
        if(enermyRY[count] != nil){
            if(enermyRY[count].tag < 900){
                float xChege = enermyRY[count].frame.origin.x;
                float yChege = enermyRY[count].frame.origin.y;
                
                if(enermyRY[count].frame.origin.x >= self.view.frame.size.width/2-25 && enermyLY[count].frame.origin.y < self.view.frame.size.height/2){
                    enermyRY[count].frame = CGRectMake(xChege-0.5, yChege+1, enermyRY[count].frame.size.width, enermyRY[count].frame.size.height);
                    
                }
                if(enermyRY[count].frame.origin.x >= self.view.frame.size.width/2-25 && enermyRY[count].frame.origin.y >= self.view.frame.size.height/2){
                    enermyRY[count].frame = CGRectMake(xChege-0.5, yChege-1, enermyRY[count].frame.size.width, enermyRY[count].frame.size.height);
                    
                }
                if(enermyRY[count].frame.origin.x + enermyRY[count].frame.size.width >= self.view.frame.size.width/2-center_imageView.frame.size.width/2 && enermyRY[count].frame.origin.x <= self.view.frame.size.width/2 + center_imageView.frame.size.width/2 && enermyRY[count].frame.origin.y +enermyRY[count].frame.size.height >= center_imageView.frame.origin.y){
                    
                    enermyRY[count].tag = 1000;
                    enermyRY[count].frame = CGRectMake(-100, 0, 60, 60);
                    //[lifeCount[life_count-1] setImage:lostImage];
                    life_count--;
                    NSLog(@"life_count33 = %i enermyRY[%i] ",life_count, count);
                    
                }
            }
        }
    }
}

-(void)EnermyClicked:(UIButton*)sender{
    
    sender.tag = 1000;
    NSURL *eneryClickedSound = [[NSBundle mainBundle] URLForResource:@"hitSoound"
                                                       withExtension:@"mp3"];
    self.hitEnermySound = [[AVAudioPlayer alloc] initWithContentsOfURL:eneryClickedSound
                                                                 error:nil];
    self.hitEnermySound.numberOfLoops = 0;
    [self.hitEnermySound play];
    
    NSLog(@"\nEnermy Dead = %f\n",sender.frame.origin.x);
    [self ImageChangeX:sender
     .frame.origin.x ImageChangeY:sender.frame.origin.y];
    sender.frame = CGRectMake(-100, 0, 60, 60);
    
    score_total +=5;
    [score_label setText:[NSString stringWithFormat:@"%i",score_total]];
}


//오징어 생기기
-(void)ImageChangeX:(float)senderX ImageChangeY:(float)senderY {
    
    UIImageView *monster_image_after_view = [[UIImageView alloc]initWithImage:monster_image_after];
    [monster_image_after_view setFrame:CGRectMake(senderX, senderY, 50, 50)];
    [self.view addSubview:monster_image_after_view];
    [UIView animateWithDuration:1.0
                          delay:0.2
                        options:nil
                     animations:^
     {
         // [monster_image_after_view setFrame:CGRectMake(100, 100, 50, 50)];
         monster_image_after_view.alpha = 0.0f;
     }
                     completion:^(BOOL finished)
     {
         [monster_image_after_view removeFromSuperview];
     }
     ];
}

-(void)levelCheck{

    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    
    StageSave *ss = [hsDB loadStage];
    self.levelSet = ss.stage;
    [hsDB databaseClose];
    NSLog(@"level = %i",levelSet);
    
    [self timeCountDownSet];
    if (levelSet == 1) {
        levelOneSet = 50;
    }else{
        levelOneSet = 100;
    }
}
-(void)timeCountDownSet{
    if (levelSet == 1) {
        time_countDown = 60;
    }else if (levelSet == 2){
        time_countDown = 60;
    }else if (levelSet == 3){
        time_countDown = 90;
    }
}

//피버
-(void)chanceView{
    chansView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview: chansView];

    for (int x = 0; x < 6; x++) {
        for (int y = 0; y < 10; y++) {
            button_ch[x][y] = [UIButton buttonWithType:UIButtonTypeCustom];
            [button_ch[x][y] setImage:monster_image_after forState:UIControlStateNormal];
            [button_ch[x][y] setFrame:CGRectMake((self.view.frame.size.width/6+1)*x, self.view.frame.size.height/30 + (self.view.frame.size.height/12*y), 50, 50)];
            [button_ch[x][y] addTarget:self action:@selector(SquidClicked:) forControlEvents:UIControlEventTouchUpInside];
            [chansView addSubview:button_ch[x][y]];
        }
    }
}

-(void)SquidClicked:(UIButton*)sender{
    NSLog(@"set");
    score_total += 10;
    self.hitEnermySound.numberOfLoops = 0;
    [self.hitEnermySound play];
    [score_label setText:[NSString stringWithFormat:@"%i",score_total]];
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:nil
                     animations:^
     {
         // [monster_image_after_view setFrame:CGRectMake(100, 100, 50, 50)];
         sender.alpha = 0.0f;
     }
                     completion:^(BOOL finished)
     {
         [sender removeFromSuperview];
     }
     ];
}

//게임 Pass/Fail 화면 띄우기
-(void)CheckView{
    
    View_count = 1;
    UIView *testView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:testView];

    UIImage *backgroud_image =[UIImage imageNamed:@"background_shadow.png"];
    UIImageView *backgroundView = [[UIImageView alloc]initWithImage:backgroud_image];
    [backgroundView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [testView addSubview:backgroundView];

    UIImage *result_image =[UIImage imageNamed:[NSString stringWithFormat:@"playing_player_result_%i.png",result_num]];
    UIImageView *result_image_view = [[UIImageView alloc]initWithImage:result_image];
    [result_image_view setFrame:CGRectMake(self.view.frame.size.width/2-315/2, self.view.frame.size.height/20, 315, 315)];
    [result_image_view setContentMode:UIViewContentModeScaleToFill];
    [backgroundView addSubview:result_image_view];

    NSLog(@"size = %f // size = %f",result_image.size.width, result_image.size.height);
    NSURL *finishTheGame_s_f = NULL;
    if (result_num == 1) {
        
        finishTheGame_s_f = [[NSBundle mainBundle] URLForResource:@"missionF"
                                                    withExtension:@"mp3"];
        
    }else if (result_num == 2){
        
        finishTheGame_s_f = [[NSBundle mainBundle] URLForResource:@"missionS"
                                                    withExtension:@"mp3"];
        
    }
    
    self.finishTheGame = [[AVAudioPlayer alloc] initWithContentsOfURL:finishTheGame_s_f
                                                                error:nil];
    self.finishTheGame.numberOfLoops = 0;
    [self.finishTheGame play];
    
    UIImage *image_textBox = [UIImage imageNamed:@"blackbox_level_time.png"];
    UIImageView *imageView_textBox = [[UIImageView alloc]initWithImage:image_textBox];
    imageView_textBox.frame = CGRectMake(self.view.frame.size.width/2- 90, result_image_view.frame.origin.y + self.view.frame.size.height/10*6-5, 180, 130);
    [imageView_textBox setContentMode:UIViewContentModeScaleToFill];
    [backgroundView addSubview:imageView_textBox];
    
    UILabel *score1_1 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/4+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6, 60, 40)];
    score1_1.text = @"획득 코인";
    [score1_1 setFont:[UIFont fontWithName:@"Arial" size:13]];
    [score1_1 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score1_1];
    
    UILabel *score1_2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6, 150, 40)];
    score1_2.text = [NSString stringWithFormat:@"%i o",score_total/5*10];
    [score1_2 setFont:[UIFont fontWithName:@"Arial" size:13]];
    [score1_2 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score1_2];
    
    UILabel *score2_1 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/4+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6 + 40, 60, 40)];
    score2_1.text = @"보너스 코인";
    [score2_1 setFont:[UIFont fontWithName:@"Arial" size:13]];
    [score2_1 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score2_1];
    
    UILabel *score2_2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6 + 40, 150, 40)];
    int bonusGage;
    if (result_num == 1) {
        bonusGage = 50;
        score2_2.text = [NSString stringWithFormat:@"-%i%%",bonusGage];
    }else if (result_num ==2){
        if (levelSet == 1) {
            bonusGage = 100;
            score2_2.text = [NSString stringWithFormat:@"%i%%",bonusGage];
        }else if (levelSet == 2){
            bonusGage = 150;
            score2_2.text = [NSString stringWithFormat:@"%i%%",bonusGage];
        }else if (levelSet == 3){
            bonusGage = 200;
            score2_2.text = [NSString stringWithFormat:@"%i%%",bonusGage];
        }
    }
    
    
    [score2_2 setFont:[UIFont fontWithName:@"Arial" size:13]];
    [score2_2 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score2_2];
    
    UILabel *score3_1 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/4+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6 + 80, 60, 40)];
    score3_1.text = @"총 합계";
    [score3_1 setFont:[UIFont fontWithName:@"Arial" size:18]];
    [score3_1 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score3_1];
    
    int totalSave = score_total/5*bonusGage/10;
    
    
    UILabel *score3_2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2+20, result_image_view.frame.origin.y + self.view.frame.size.height/10*6 + 80, 150, 40)];
    score3_2.text = [NSString stringWithFormat:@"%i o",totalSave];
    [score3_2 setFont:[UIFont fontWithName:@"Arial" size:18]];
    [score3_2 setTextColor:[UIColor yellowColor]];
    [backgroundView addSubview:score3_2];
    
    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    [hsDB createTable];
    CoinSave *cs = [hsDB loadCoin];
    totalSave = totalSave + cs.coin;
    [hsDB insertSaveCoin:totalSave];
    [hsDB databaseClose];
    
    UIImage *image_resultbt = [UIImage imageNamed:@"try_again_button_before.png"];
    UIButton *resultViewbt = [UIButton buttonWithType:UIButtonTypeCustom];
    [resultViewbt setImage:image_resultbt forState:UIControlStateNormal];
    [resultViewbt setFrame:CGRectMake(self.view.frame.size.width/2-60, result_image_view.frame.origin.y+self.view.frame.size.height/10*8+20, 120, 50)];
    [resultViewbt addTarget:self action:@selector(buttonResultView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:resultViewbt];
    
    //[self chanceView];
}

//결과 본 후 이동 및 데이타 초기화
-(void)buttonResultView{
    NSLog(@"결과View로 이동");
    View_count = 0;
    
    [self timeCountDownSet];
    
    timer_count = 0;
    timer_count_1 = 0;
    timer_count_2 = 0;
    life_count = 5;
    chracter_move = 0;
    
    continueTimer = 0;
    introViewCount = 0;
    time_counter = 0;
    
    x_loop_count = 0;
    ly_loop = 0;
    ry_loop = 0;
    
    lifeCount_set = 5;
    bonusView = 0;
    callBonusView = 1;
    
    [self.finishTheGame stop];
    
    ViewController *viewcontroller = [[ViewController alloc] init];
    [self presentViewController:viewcontroller animated:YES completion:nil];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
