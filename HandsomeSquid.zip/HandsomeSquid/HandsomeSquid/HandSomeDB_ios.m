//
//  HandSomeDB_ios.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "HandSomeDB_ios.h"

@implementation HandSomeDB_ios

//DB 경로 설정
+(NSString *)dbPath {
    //Documents 폴더를 가져온다.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *documents = [paths objectAtIndex:0];
    //db.sql을 가져온 폴더내 붙여서 리턴한다.
    NSString *path = [documents stringByAppendingPathComponent:@"handsomeDB.sql"];
    NSLog(@"%@",path);
    return path;
}

//DB생성 및 열기
-(void)openDB{
    //파일이 없으면 파일을 생성하고 파일 있으면 생성은 건너뛴다.
    //이후 해당 파일을 열어서 프로그램상에서 사용할 수 있도록 하는 구문이다.
    if (sqlite3_open([[HandSomeDB_ios dbPath] UTF8String], &db)!=SQLITE_OK) {
        //실패했을 경우 DB(파일)를 닫는다.
        sqlite3_close(db);
        NSLog(@"DB오픈 실패");
    } else {
        NSLog(@"DB오픈 성공");
    }
}

//테이블 생성
-(void)createTable{
    char *err; //sql 실행시 에러코드 (에러가 났을경우) 에러값을 포인터로 생성
    //테이블 생성을 위한 sql구문
    NSString *sql[] = {
        
//        @"DROP TABLE SaveLevel",
//        @"DROP TABLE SaveCoin",
        @"CREATE TABLE IF NOT EXISTS SaveLevel (SLeq INTEGER PRIMARY KEY, SLevel INTEGER)",
        @"CREATE TABLE IF NOT EXISTS SaveCoin (CLeq INTEGER PRIMARY KEY, SCoin INTEGER)",
        //',' 를 넣줘야 함**
        
    };
    
    for (int i=0; i<2; i++) {
        //sql 실행
        if(sqlite3_exec(db, [sql[i] UTF8String], NULL, NULL, &err)!=SQLITE_OK){
            //실패하면 sql 종료
            sqlite3_close(db);
            
            //에러가 났다면 에러가 난 사유를 받아오는 구조를 작성하는 편이다. 통신이 된다는 가정하에..
            NSLog(@"table 생성 실패:%s",err);
        }else {
            NSLog(@"table");
        }
    }
}

-(void)insertGameData {
    char *err; //sql 실행시 에러코드 (에러가 났을경우) 에러값을 포인터로 생성
    
    NSString *sql[] = {
        
        @"INSERT OR REPLACE INTO SaveLevel (SLeq, SLevel) VALUES (1,1);",
        @"INSERT OR REPLACE INTO SaveCoin (CLeq, SCoin) VALUES (1,1);",
    };
    //i<2 = 테이블 2개
    for (int i=0; i<2; i++) {
        //sql 실행
        if(sqlite3_exec(db, [sql[i] UTF8String], NULL, NULL, &err)!=SQLITE_OK){
            //실패하면 sql 종료
            sqlite3_close(db);
            
            //에러가 났다면 에러가 난 사유를 받아오는 구조를 작성하는 편이다. 통신이 된다는 가정하에..
            NSLog(@"insert 실패:%s",err);
        }else {
            NSLog(@"insert");
        }
    }
}

-(void)insertGame:(int)num{
    NSString *sql = @"INSERT OR REPLACE INTO SaveLevel (SLeq, SLevel) VALUES (?,?);";
    sqlite3_stmt *statment;
    NSLog(@"뜸");
    //대입될 값을 설정
    if (sqlite3_prepare_v2(db, [sql UTF8String], -1, &statment, NULL) ==SQLITE_OK) {
        sqlite3_bind_int(statment, 1, 1);
        sqlite3_bind_int(statment, 2, num);
    }
    NSLog(@"num = %i",num);
    //검사- 검사및실행
    if (sqlite3_step(statment) != SQLITE_DONE) {
        NSLog(@"추가 실패");
    } else {
        NSLog(@"test");
    }
    //실행
    sqlite3_finalize(statment);
}

-(void)insertSaveCoin:(int)Coin{
    
    NSString *sql = @"INSERT OR REPLACE INTO SaveCoin (CLeq, SCoin) VALUES (?,?);";
    sqlite3_stmt *statment;
    NSLog(@"뜸");
    //대입될 값을 설정
    if (sqlite3_prepare_v2(db, [sql UTF8String], -1, &statment, NULL) ==SQLITE_OK) {
        sqlite3_bind_int(statment, 1, 1);
        sqlite3_bind_int(statment, 2, Coin);
    }
    NSLog(@"num = %i",Coin);
    //검사- 검사및실행
    if (sqlite3_step(statment) != SQLITE_DONE) {
        NSLog(@"추가 실패");
    } else {
        NSLog(@"코인 저장 성공");
    }
    //실행
    sqlite3_finalize(statment);
    
}

-(StageSave*)loadStage{
    StageSave *ssave = [[StageSave alloc]init];
    NSString *sql = @"SELECT SLevel FROM SaveLevel WHERE SLeq = 1";
    sqlite3_stmt *statment;
    if (sqlite3_prepare_v2(db, [sql UTF8String], -1, &statment, NULL) == SQLITE_OK) {
        while (sqlite3_step(statment) == SQLITE_ROW) {
            int stageCheck = sqlite3_column_int(statment, 0);
            
            ssave.stage = stageCheck;
            
        }
        sqlite3_finalize(statment);
    }
    return ssave;
}

-(CoinSave*)loadCoin{
    CoinSave *ssave = [[CoinSave alloc]init];
    NSString *sql = @"SELECT SCoin FROM SaveCoin WHERE CLeq = 1";
    sqlite3_stmt *statment;
    if (sqlite3_prepare_v2(db, [sql UTF8String], -1, &statment, NULL) == SQLITE_OK) {
        while (sqlite3_step(statment) == SQLITE_ROW) {
            int stageCheck = sqlite3_column_int(statment, 0);
            
            ssave.coin = stageCheck;
            
        }
        sqlite3_finalize(statment);
    }
    return ssave;
}

-(void)databaseClose{
    sqlite3_close(db);
}

@end
