//
//  CoinSave.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "CoinSave.h"

@implementation CoinSave

@synthesize coin;

@end
