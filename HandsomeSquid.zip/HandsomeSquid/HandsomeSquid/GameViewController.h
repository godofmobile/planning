//
//  GameViewController.h
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface GameViewController : UIViewController

@property int levelSet;

@property (nonatomic, strong) AVAudioPlayer *backgroundMusic;
@property (nonatomic, strong) AVAudioPlayer *hitEnermySound;
@property (nonatomic, strong) AVAudioPlayer *finishTheGame;

@end
