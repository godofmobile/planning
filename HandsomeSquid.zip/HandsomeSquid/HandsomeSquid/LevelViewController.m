//
//  LevelViewController.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "LevelViewController.h"
#import "ViewController.h"
#import "HandSomeDB_ios.h"
#import "StageSave.h"

@interface LevelViewController ()

@end

@implementation LevelViewController

UIImageView *imageView_back;
UIImageView *imageView_backshadow;
UIImageView *imageViewback_text;
UIImageView *imageView_MaleFemale;

UILabel *buttonLabel;

int count_level = 0;

NSArray *levelArray;
NSArray *timeArray;
NSArray *rewardArray;

UIButton *selectChabutton[3];

UIImage *image_she[3];
UIImage *image_Male;
UIImage *image_Female;

- (void)viewDidLoad {
    
    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    StageSave *ss = [hsDB loadStage];
    count_level = ss.stage - 1;
    
    [hsDB databaseClose];
    
    if (count_level <0) {
        count_level = 0;
    }
    
    UIImage *image_back = [UIImage imageNamed:@"background_sub.png"];
    imageView_back = [[UIImageView alloc]initWithImage:image_back];
    [imageView_back setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:imageView_back];
    
    UIImage *image_backshadow = [UIImage imageNamed:@"background_shadow.png"];
    imageView_backshadow = [[UIImageView alloc]initWithImage:image_backshadow];
    [imageView_backshadow setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [imageView_back addSubview:imageView_backshadow];
    
    UIImage *imageback_text = [UIImage imageNamed:@"image_who_is_your_girl_friend_tiping.png"];
    imageViewback_text = [[UIImageView alloc]initWithImage:imageback_text];
    [imageViewback_text setFrame:CGRectMake(self.view.frame.size.width/2-imageback_text.size.width/3*2/2, self.view.frame.size.height/6.5, imageback_text.size.width/3*2, imageback_text.size.height/3*2)];
    [imageView_back addSubview:imageViewback_text];
    
    
    
    for (int i = 0; i <3; i++) {
        image_she[i] = [UIImage imageNamed:[NSString stringWithFormat:@"image_who_is_your_girlfriend_%i.png",i+1]];
        selectChabutton[i] = [UIButton buttonWithType:UIButtonTypeCustom];
        [selectChabutton[i] setImage:image_she[i] forState:UIControlStateNormal];
        selectChabutton[i].contentMode = UIViewContentModeScaleToFill;
        selectChabutton[i].contentHorizontalAlignment = UIControlContentHorizontalAlignmentFill;
        selectChabutton[i].contentVerticalAlignment = UIControlContentVerticalAlignmentFill;
        selectChabutton[i].tag = i+1;
        [selectChabutton[i] addTarget:self action:@selector(charactSelect:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:selectChabutton[i]];
    }

    
    levelArray = [NSArray arrayWithObjects:@"하",@"중",@"상" , nil];
    timeArray = [NSArray arrayWithObjects:@"60",@"60",@"90" , nil];
    rewardArray = [NSArray arrayWithObjects:@"성공 : 100%\n실패시 : 50%",@"성공 : 150%\n실패시 : 50%", @"성공 : 200%\n실패시 : 50%", nil];
    
    buttonLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2 - 50, self.view.frame.size.height/3*2, 100, 200)];
    buttonLabel.numberOfLines = 4;
    [buttonLabel setTextAlignment:NSTextAlignmentLeft];
    [self.view addSubview:buttonLabel];
    
    
    [self centerImageSet:count_level];
    
    UIImage *image_goBack = [UIImage imageNamed:@"button_goback.png"];
    UIButton *button_goBack = [UIButton buttonWithType:UIButtonTypeCustom];
    [button_goBack setImage:image_goBack forState:UIControlStateNormal];
    [button_goBack setFrame:CGRectMake(15, 20, image_goBack.size.width/3*2, image_goBack.size.height/3*2)];
    [button_goBack addTarget:self action:@selector(myinfoBt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button_goBack];

    image_Male = [UIImage imageNamed:@"button_male_O_female_X.png"];
    image_Female = [UIImage imageNamed:@"button_male_X_female_O.png"];
    imageView_MaleFemale = [[UIImageView alloc]initWithImage:image_Male];
    [imageView_MaleFemale setFrame:CGRectMake(self.view.frame.size.width/2-image_Male.size.width/2, self.view.frame.size.height/20, image_Male.size.width, image_Male.size.height)];
    [self.view addSubview:imageView_MaleFemale];
    
    UIButton *button_MF[2];
    for (int i = 0; i < 2; i++) {
        button_MF[i] = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [button_MF[i] setFrame:CGRectMake(imageView_MaleFemale.frame.origin.x*(i+1), imageView_MaleFemale.frame.origin.y, imageView_MaleFemale.frame.size.width/2, imageView_MaleFemale.frame.size.height)];
        button_MF[i].tag = i;
        button_MF[i].alpha = 0.1f;
        [button_MF[i] addTarget:self action:@selector(cilckedMF:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button_MF[i]];
    }

    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)myinfoBt{
    ViewController *viewController = [[ViewController alloc] init];
    [self presentViewController:viewController animated:NO completion:nil];
}

-(void)cilckedMF:(UIButton*)sender{
    NSLog(@"sender = %i",(int)sender.tag);
    if ((int)sender.tag == 0) {
        [imageView_MaleFemale setImage:image_Male];
    
    }else if ((int)sender.tag == 1){
        [imageView_MaleFemale setImage:image_Female];
    
    }
}

-(void)charactSelect:(UIButton*)sender{
    NSLog(@"%ld 번째 여성 눌림",(long)sender.tag);
    HandSomeDB_ios *hsDB = [[HandSomeDB_ios alloc]init];
    [hsDB openDB];
    [hsDB createTable];
    [hsDB insertGame:(int)sender.tag];
    [hsDB databaseClose];
    count_level = (int)sender.tag -1;
    [self centerImageSet:count_level];
    
}
-(void)centerImageSet:(int)count{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.70];
    [UIView setAnimationDelay:0.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];

    if (count == 0) {
        for (int i = 0; i <3; i++) {
            [selectChabutton[i] setFrame:CGRectMake(self.view.frame.size.width/3*(i+1), self.view.frame.size.height/2.5, image_she[i].size.width , image_she[i].size.height)];
        }
        [selectChabutton[count_level] setFrame:CGRectMake(self.view.frame.size.width/3-15, self.view.frame.size.height/2.5, image_she[count].size.width*4/3 , image_she[count].size.height*4/3)];
    }else if (count == 1){
        for (int i = 0; i <3; i++) {
            [selectChabutton[i] setFrame:CGRectMake(self.view.frame.size.width/3*i, self.view.frame.size.height/2.5, image_she[i].size.width , image_she[i].size.height)];
        }
        [selectChabutton[count_level] setFrame:CGRectMake(self.view.frame.size.width/3-15, self.view.frame.size.height/2.5, image_she[count].size.width*4/3 , image_she[count].size.height*4/3)];
        
    }else if (count == 2){
        for (int i = 0; i <3; i++) {
            [selectChabutton[i] setFrame:CGRectMake(self.view.frame.size.width/3*(i-1), self.view.frame.size.height/2.5, image_she[i].size.width , image_she[i].size.height)];
        }
        [selectChabutton[count_level] setFrame:CGRectMake(self.view.frame.size.width/3-15, self.view.frame.size.height/2.5, image_she[count].size.width*4/3 , image_she[count].size.height*4/3)];
    }
    [UIView commitAnimations];
    buttonLabel.text = [NSString stringWithFormat:@"난이도 : %@\n시간  : %@\n%@",[levelArray objectAtIndex:count],[timeArray objectAtIndex:count],[rewardArray objectAtIndex:count]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
