//
//  AvataViewController.m
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import "AvataViewController.h"
#import "ViewController.h"

@interface AvataViewController ()

@end

@implementation AvataViewController
UIImage *avata_image1;
UIImage *avata_image2;

UIImageView *avata_view;


- (void)viewDidLoad {
    UIImage *imageback = [UIImage imageNamed:@"background_sub.png"];
    UIImageView *imageViewback = [[UIImageView alloc]initWithImage:imageback];
    [imageViewback setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:imageViewback];
    
    UIImage *imageback_shadow = [UIImage imageNamed:@"background_shadow.png"];
    UIImageView *imageViewback_shadow = [[UIImageView alloc]initWithImage:imageback_shadow];
    [imageViewback_shadow setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [imageViewback addSubview:imageViewback_shadow];
    
    UIImage *myinfoImage = [UIImage imageNamed:@"button_goback.png"];
    UIButton *myinfoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [myinfoButton setImage:myinfoImage forState:UIControlStateNormal];
    [myinfoButton setFrame:CGRectMake(15, 20, myinfoImage.size.width/3*2, myinfoImage.size.height/3*2)];
    [myinfoButton addTarget:self action:@selector(myinfoBt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:myinfoButton];
    
    UIImage *left = [UIImage imageNamed:@"triangle_left.png"];
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftButton setImage:left forState:UIControlStateNormal];
    [leftButton setFrame:CGRectMake(0, self.view.frame.size.height/2-left.size.height/2, left.size.width, left.size.height)];
    [leftButton addTarget:self action:@selector(leftBt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftButton];
    
    UIImage *right = [UIImage imageNamed:@"triangale_right.png"];
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:right forState:UIControlStateNormal];
    [rightButton setFrame:CGRectMake(self.view.frame.size.width-right.size.width, self.view.frame.size.height/2-right.size.height/2, right.size.width, right.size.height)];
    [rightButton addTarget:self action:@selector(rightBt) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightButton];
    
    avata_image1 = [UIImage imageNamed:@"avata_ver1.png"];
    avata_image2 = [UIImage imageNamed:@"avata_ver2.png"];
    avata_view = [[UIImageView alloc]initWithImage:avata_image1];
    [avata_view setFrame:CGRectMake(self.view.frame.size.width/2-avata_image1.size.width/2, 150, avata_image1.size.width, avata_image1.size.height)];
    [self.view addSubview:avata_view];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)myinfoBt{
    ViewController *viewController = [[ViewController alloc] init];
    [self presentViewController:viewController animated:NO completion:nil];
}

-(void)leftBt{
    NSLog(@"image1");
    [avata_view setImage:avata_image1];
    
}

-(void)rightBt{
    [avata_view setImage:avata_image2];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
