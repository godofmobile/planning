//
//  HandSomeDB_ios.h
//  HandsomeSquid
//
//  Created by SongHyunKwan on 2016. 12. 2..
//  Copyright © 2016년 SongHyunKwan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StageSave.h"
#import "CoinSave.h"
#import "sqlite3.h"

@interface HandSomeDB_ios : NSObject{
    
    sqlite3 * db;
    
}

+(NSString *)dbPath;
-(void)openDB;
-(void)createTable;
-(void)insertGameData;
-(void)insertGame:(int)num;
-(void)insertSaveCoin:(int)Coin;

-(StageSave*)loadStage;
-(CoinSave*)loadCoin;

-(void)databaseClose;


@end
